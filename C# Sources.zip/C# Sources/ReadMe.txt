if you got error install this nuget package 
_____________________________________________

System.Text.Json